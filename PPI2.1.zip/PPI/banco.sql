-- --------------------------------------------------------
-- Servidor:                     127.0.0.1
-- Versão do servidor:           10.4.32-MariaDB - mariadb.org binary distribution
-- OS do Servidor:               Win64
-- HeidiSQL Versão:              12.7.0.6850
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Copiando estrutura do banco de dados para ppi
CREATE DATABASE IF NOT EXISTS `ppi` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci */;
USE `ppi`;

-- Copiando estrutura para tabela ppi.alocaçao
CREATE TABLE IF NOT EXISTS `alocaçao` (
  `id_alocacao` int(11) NOT NULL AUTO_INCREMENT,
  `data_retirada` date NOT NULL,
  `data_devolucao` date NOT NULL,
  `armario` int(11) NOT NULL,
  `estudante` int(11) NOT NULL,
  `status` varchar(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`id_alocacao`),
  KEY `FK_alocaçao_armario` (`armario`),
  KEY `FK_alocaçao_estudante` (`estudante`),
  CONSTRAINT `FK_alocaçao_armario` FOREIGN KEY (`armario`) REFERENCES `armario` (`id_armario`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_alocaçao_estudante` FOREIGN KEY (`estudante`) REFERENCES `estudante` (`matricula`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Copiando dados para a tabela ppi.alocaçao: ~0 rows (aproximadamente)

-- Copiando estrutura para tabela ppi.armario
CREATE TABLE IF NOT EXISTS `armario` (
  `id_armario` int(11) NOT NULL AUTO_INCREMENT,
  `disponibilidade` varchar(50) NOT NULL,
  `historico` varchar(100) NOT NULL,
  `id_bloco` int(3) NOT NULL,
  PRIMARY KEY (`id_armario`),
  KEY `FK__bloco` (`id_bloco`),
  CONSTRAINT `FK__bloco` FOREIGN KEY (`id_bloco`) REFERENCES `bloco` (`id_bloco`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Copiando dados para a tabela ppi.armario: ~0 rows (aproximadamente)

-- Copiando estrutura para tabela ppi.bloco
CREATE TABLE IF NOT EXISTS `bloco` (
  `id_bloco` int(3) NOT NULL AUTO_INCREMENT,
  `predio` varchar(50) NOT NULL,
  PRIMARY KEY (`id_bloco`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Copiando dados para a tabela ppi.bloco: ~0 rows (aproximadamente)

-- Copiando estrutura para tabela ppi.estudante
CREATE TABLE IF NOT EXISTS `estudante` (
  `matricula` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) DEFAULT NULL,
  `nome` varchar(50) DEFAULT NULL,
  `telefone` int(12) DEFAULT NULL,
  `curso` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`matricula`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Copiando dados para a tabela ppi.estudante: ~0 rows (aproximadamente)

-- Copiando estrutura para tabela ppi.manutençao
CREATE TABLE IF NOT EXISTS `manutençao` (
  `id_manutençao` int(11) NOT NULL AUTO_INCREMENT,
  `dia` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  `observaçoes` varchar(300) DEFAULT NULL,
  `satus` varchar(50) DEFAULT NULL,
  `id_armario` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_manutençao`),
  KEY `FK__armario` (`id_armario`),
  CONSTRAINT `FK__armario` FOREIGN KEY (`id_armario`) REFERENCES `armario` (`id_armario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Copiando dados para a tabela ppi.manutençao: ~0 rows (aproximadamente)

-- Copiando estrutura para tabela ppi.usuario
CREATE TABLE IF NOT EXISTS `usuario` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) DEFAULT NULL,
  `cpf` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Copiando dados para a tabela ppi.usuario: ~0 rows (aproximadamente)

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
