
    <!doctype html>
    <html lang='pt-br'>
    <head>
        <meta charset='utf-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1'>
        <title>Sistema de armários</title>
        <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css' rel='stylesheet' integrity='sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN' crossorigin='anonymous'>
    </head>
    <body>
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="h1 text-center pt-5">
                        <?php echo "Box 1"?>
                    </div>
                    <?php
                    echo "<div class='row text-center mx-auto'>";
                    for($i = 1; $i<=20; $i++){
                        echo "
                        <div class='col-6 col-md-3 py-3 d-flex justify-content-center'>
                            <div class='card' style='width: 10rem;'>
                                <div class='card-body'>
                                    <h5 class='card-title'>$i</h5>
                                    <!-- Button trigger modal -->
                                    <button type='button' class='btn btn-link' data-bs-toggle='modal' data-bs-target='#exampleModalCenter'>
                                        Ver
                                    </button>
                                    
                                    <!-- Modal -->
                                    <div class='modal fade' id='exampleModalCenter' tabindex='-1' role='dialog' aria-labelledby='exampleModalCenterTitle' aria-hidden='true'>
                                        <div class='modal-dialog modal-dialog-centered' role='document'>
                                        <div class='modal-content'>
                                            <div class='modal-header'>
                                            <h5 class='modal-title' id='exampleModalLongTitle'>Armário $i</h5>
                                            <button type='button' class='close' data-bs-dismiss='modal' aria-label='Close'>
                                                <span aria-hidden='true'>&times;</span>
                                            </button>
                                            </div>
                                            <div class='modal-body text-left'>
                                                    <form>
                                                    <div class='form-group'>
                                                    <label for='disponibilidade'>Disponibilidade</label>
                                                    <select class='form-control'  name='disponibilidade' id='disponibilidade' name='disponibilidade'>
                                                    <option value='valor1'>Disponível</option>
                                                    <option value='valor2' selected>Ocupado</option>
                                                    <option value='valor3'>Danificado</option>
                                                    </select>
                                                    </div>
                                                    <div class='form-group'>
                                                    <label for='aluno'>Aluno</label>
                                                    <input type='text' class='form-control' id='aluno'>
                                                    </div>
                                                    <div class='form-group'>
                                                    <label for='matricula'>Matrícula</label>
                                                    <input type='text' class='form-control' id='matricula'>
                                                    </div>
                                                    <div class='form-group'>
                                                    <label for='email'>E-mail</label>
                                                    <input type='email' class='form-control' id='email'>
                                                    </div>
                                                    <div class='form-group'>
                                                    <label for='curso'>Curso</label>
                                                    <select class='form-control'  name='curso' id='curso' name='curso'>
                                                    <option value='valor1'>Técnico em Alimentos</option>
                                                    <option value='valor2' selected>Técnico em Informática</option>
                                                    <option value='valor3'>Técnico em Administração</option>
                                                    <option value='valor3'>Técnico em Agropecuária</option>
                                                    </select>
                                                    </div>
                                                    <div class='form-group'>
                                                    <label for='ano'>Ano</label>
                                                    <select class='form-control'  name='ano' id='ano' name='ano'>
                                                    <option value='valor1'>1º ano</option>
                                                    <option value='valor2' selected>2º ano</option>
                                                    <option value='valor3'>3º ano</option>
                                                    </select>
                                                    </div>
                                            </div>
                                            <div class='modal-footer'>
                                            <button type='button' class='btn btn-danger' data-bs-dismiss='modal'>Cancelar</button>
                                            <button type='submit' class='btn btn-success'>Cadastrar</button>
                                            </form>
                                            <button type='button' class='btn btn-link'>
                                             <a href='configuracaoarmario.php/?a=$i'>Configurações</a>
                                        </button>
                                            </div>
                                        </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        ";
                    }
                    echo "</div>";
                    ?>
                    
                </div>
            </div>
        </div>
        <script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js' integrity='sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL' crossorigin='anonymous'></script>
        <script src='https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js' integrity='sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r' crossorigin='anonymous'></script>
        <script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js' integrity='sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+' crossorigin='anonymous'></script>
    </body>
</html>
