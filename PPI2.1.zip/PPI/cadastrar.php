<?php
$host = "localhost";
$username = "root"; // Nome de usuário padrão do XAMPP
$password = ""; // Senha padrão vazia para o usuário root no XAMPP
$database = "ppi"; // Nome do banco de dados

// Cria conexão com o banco de dados
$mysqli = new mysqli($host, $username, $password, $database);

// Verifica se a conexão foi bem-sucedida
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Recebe os dados do formulário
$nome = $_POST['nome'];
$email = $_POST['email'];
$senha = $_POST['senha'];

// Prepara a query para evitar SQL Injection
$stmt = $mysqli->prepare("INSERT INTO estudante (nome, email, telefone, curso) VALUES (?, ?, NULL, NULL)");
$stmt->bind_param("ss", $nome, $email);

// Executa a query e verifica o sucesso
if ($stmt->execute()) {
    echo "success"; // Mensagem de sucesso
} else {
    echo "error"; // Mensagem de erro
}

// Fecha a conexão
$stmt->close();
$mysqli->close();
?>
