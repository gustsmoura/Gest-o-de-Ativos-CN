
<?php

$num = $_GET['a'];

echo "Configurações para o armário $num";

?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="Styleconfig.css">
</head>
<div class="row">
    <div class="col-12">
        <div class='text-center' role='document'>

        
                    <a href='' class='btn btn-link text-dark' target='_blank'>Adicionar aluno ao armário</a> <br>
                    <a href='' class='btn btn-link text-dark' target='_blank'>Adicionar alerta ao armário</a> <br>
                    <a href='' class='btn btn-link text-dark' target='_blank'>Excluir box</a> <br>
                    <a href='' class='btn btn-link text-dark' target='_blank'>Excluir aluno do armário</a> <br>
                    <a href='' class='btn btn-link text-dark' target='_blank'>Histórico do armário</a> <br>
                    <a href='' class='btn btn-link text-dark' target='_blank'>Realocar aluno</a> <br>
                    <a href='' class='btn btn-link text-dark' target='_blank'> Realocar armário</a> <br>
                
                    

            
        </div>
    </div>
</div>
