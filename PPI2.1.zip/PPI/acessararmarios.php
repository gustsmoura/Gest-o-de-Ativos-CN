<!doctype html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>IFFar Armários</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="./styles.css">
    <style>
        .corpo{
                padding-left: 150px;
                background-color: yellow;
                min-height: 50vh;
                min-width: 100vw;
                }
        .bloco{
            height:400px; 
            background-color:blue; 
            border-radius:8px;
        }
        .armario{
            background-color:pink; 
            min-height: 100px;
            border-radius:5px;
        }
    </style>
</head>

<body>

    <!--Navbar-->

    <nav class="navbar navbar-expand-lg navbar-success bg-success">
        <button class="btn btn-success" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasExample"
            aria-controls="offcanvasExample">
            <i class="bi bi-justify"></i>
        </button>
        <div class="mx-auto text-white">
            <h1>Armários</h1>
        </div>
        <div class="navbar-text text-white px-4">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-search"
                viewBox="0 0 16 16">
                <path
                    d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
            </svg>
        </div>
    </nav>

    <!--Dropdawn&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Menu&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-->
    <div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">
        <div class="offcanvas-body">
            <div class="dropdown mt-3">
                <ul>
                    <div class="row">
                        <div class="offset-9">
                            <button type="button" class="btn-close" data-bs-dismiss="offcanvas"
                                aria-label="Fechar"></button><br>
                        </div>
                    </div>

                    <h3 class="thick"
                        style="font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif; font-size: 250%;">
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Menu&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    </h3><br>
                    <a href="index.html" style="font-size: 150%; padding-right: 50%;">Página Inicial</a><br><br>
                    <a href="informacoes.html" style="font-size: 150%;  padding-right: 50%;">Informações</a><br><br>
                    <a href="mapa.html" style="font-size: 150%; padding-right: 50%;">Mapa</a><br><br>
                    <a href="alunos.html" style="font-size: 150%; padding-right: 45%;">Adicionar Alunos</a><br><br>
                </ul>
            </div>
        </div>
    </div>


    <!--/Dropdawn-->

    <!--/Navbar-->


    <!--Conteúdo-->

    <div class="row corpo ">
        
            <?php
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "ppi";
            
            // Create connection
            $conn = mysqli_connect($servername, $username, $password, $dbname);
            // Check connection
            if (!$conn) {
              die("Connection failed: " . mysqli_connect_error());
            }
            
            $sql = "SELECT * from bloco";
            $result = mysqli_query($conn, $sql);
            
            if (mysqli_num_rows($result) > 0) {
              // output data of each row
              while($row = mysqli_fetch_assoc($result)) {
                
                echo "<div class='col-3 m-2 bloco'> ";
                
                echo "<h4> Prédio ".$row['predio']."</h4>";

                /* Aqui vai selecionar os armários do bloco*/ 
                $sql1 = "SELECT * from armario where id_bloco='".$row['id_bloco']."'";
                //echo $sql1;
                $result1 = mysqli_query($conn, $sql1);
                if (mysqli_num_rows($result1) > 0) {
                    echo "<div class='row'>";
                    while($row1 = mysqli_fetch_assoc($result1)) {

                        echo "<div class='col-3 m-1 p-1 armario'>";
                            echo "Nº: ".$row1["id_armario"];
                            echo "<br>".$row1["disponibilidade"];
                        echo "</div>";
                    }
                    echo "</div>";
                }
                echo "</div>";
              }
            } else {
              echo "0 results";
            }
            
            mysqli_close($conn);

            ?>
        
    </div>
    <!--/Conteúdo-->


    <!--Bibliotecas Obrigatórias-->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
        integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
        integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+"
        crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <!--/Bibliotecas Obrigatórias-->

</body>

</html>

<?php
function listaArmarios($bloco){
    $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "ppi";
            
            // Create connection
            $conn = mysqli_connect($servername, $username, $password, $dbname);
            // Check connection
            if (!$conn) {
              die("Connection failed: " . mysqli_connect_error());
            }
            
            $sql = "SELECT * from armario where id_bloco = $bloco; ";
            $result = mysqli_query($conn, $sql);
            
            if (mysqli_num_rows($result) > 0) {
              // output data of each row
              while($row = mysqli_fetch_assoc($result)) {
                echo $row["id_armario"];
              }
            } else {
              echo "0 results";
            }
            
            mysqli_close($conn);
}
?>